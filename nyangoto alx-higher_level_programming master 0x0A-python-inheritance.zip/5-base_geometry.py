#!/usr/bin/python3
"""
Contains definition of the empty class BaseGeometry
"""


class BaseGeometry():
    """Definition of empty class BaseGeometry"""
    pass
